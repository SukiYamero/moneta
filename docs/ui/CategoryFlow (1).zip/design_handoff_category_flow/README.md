# Handoff: Category Picker Flow (Add Income/Expense)

## Overview
An alternate way to assign a category on the "Add income / expense" sheet. Instead of scrolling a row of tag chips, the user taps a single "Category" field that opens a full-screen-ish modal: a grid of general categories, and tapping one that has subcategories drills into a second level (that category + its subcategories) to pick the final tag. A floating pill button on the sheet lets the user swap between the original tag-chips UI and this new category-modal UI (both live side by side for exploration/demo purposes).

## About the Design Files
The bundled file (`Moneta.dc.html`) is a **design reference** built in HTML/React-like template syntax for a design tool — not production code to copy directly. Recreate this flow in the target app's existing stack (React Native, SwiftUI, Kotlin/Compose, etc.) using its own component library, state management, and navigation patterns. Use this doc + the file as the spec for behavior, layout, and visual detail.

## Fidelity
**High-fidelity.** Colors, spacing, radii, type sizes and copy are final-ish and should be recreated closely. Icons are from the [Phosphor Icons](https://phosphoricons.com/) set (`ph ph-*` class names below map 1:1 to Phosphor icon names) — swap for the equivalent icon in whatever icon set the target app uses.

## Screens / Views

### 1. Add sheet — mode toggle
A floating pill button sits centered at the top of the add-income/expense sheet, above the amount/date/etc. fields, z-order above everything else on the sheet.
- Position: absolute, `top: 16px`, horizontally centered.
- Shape: pill, `border-radius: 999px`, `padding: 9px 15px`.
- Style: translucent surface background (`~92% opacity surface color`) with `backdrop-filter: blur(6px)`, 1px border, drop shadow (`0 8px 20px rgba(0,0,0,.28)`).
- Content: a flask/lab icon (accent color) + label text, `12px / 800 weight`.
- Label toggles between **"Vista: Etiquetas"** (tags mode, default) and **"Vista: Categorías"** (category mode).
- Tapping it flips the sheet's category-selection UI between the two modes described below. Nothing else on the sheet changes.

### 2. Tags mode (existing/default)
Unchanged — a fixed column (search-all-tags button + "Custom" button) beside a 2-row horizontally scrolling carousel of tag chips. Documented here only for contrast; not part of the new work.

### 3. Category mode — single field
Replaces the tag carousel entirely when category mode is active.
- Label above: "Categoría", `11.5px / 700`, uppercase, muted color, `letter-spacing: .5px`.
- A single full-width button/row, `height` auto (`padding: 11px 13px`), `border-radius: 16px`, 1px border, background = page background color.
- Row content (flex, `gap: 11px`):
  - 34×34px icon swatch, `border-radius: 11px`, background = a **soft/light tint of the category's color at ~14% opacity** (not a strong/saturated background), icon in the category's full color, `16px` icon size.
  - Label: category name if one is picked (`14px / 700`, primary text color) or "Elegir categoría" placeholder (muted color) if none picked yet. Truncates with ellipsis.
  - Trailing chevron-right icon, muted color.
- Tapping the row opens the Category Modal (Level 1).

**Design note on the tint:** an earlier version used a stronger/more saturated background for the selected state, and it read as too heavy — the swatch background must stay a **light, soft tint** of the category color, not a solid or dark fill.

### 4. Category Modal — Level 1 (general categories)
A bottom-sheet-style modal, presented as large as reasonably possible without being a full new screen/page (keep it feeling "light" — a modal, not a navigation push).
- Backdrop: full-screen scrim, `rgba(0,0,0,.6)`, tap to dismiss.
- Sheet: anchored to the bottom, `max-height: 98%` of the screen, rounded top corners (`30px`) and slightly more rounded bottom corners (`44px`, matching the device's own corner radius so it reads flush at the very bottom), scrollable if content overflows.
- Drag handle: small centered bar at the top (`38×5px`, rounded, muted).
- Header row: title "Categoría" (`17px / 800`) + a small circular close (X) button (`32×32px`, `border-radius: 11px`, muted background) top-right.
- **Search bar:** directly under the header. Rounded field (`border-radius: 14px`, `height: 44px`, 1px border, page-background fill) with a magnifying-glass icon + text input, placeholder "Buscar categoría". Filters the grid below by category name, case-insensitive substring match, live as you type.
- **Grid:** 3 columns, `gap: 8px`. Each cell is a button:
  - `border-radius: 16px`, `padding: 11px 6px`, flex-column, centered, `gap: 6px`.
  - 36×36px icon swatch (`border-radius: 12px`), soft color tint background, full-color icon, `16px` icon size.
  - Name label below, `11px / 700`, centered, clamped to 2 lines (`-webkit-line-clamp: 2`) so long names don't overflow the tile.
- **First tile is always "Custom":** a dashed-border tile (`border: 1px dashed`, transparent background), plus icon, muted text/icon color, label "Custom". **Per current spec this button currently does nothing when tapped** — it's a placeholder for a future "create your own category" flow that was scoped out of this handoff. Wire it up as a no-op (or hide it) until that flow is designed.
- **Pagination:** the grid shows **9 categories per page** (3 rows × 3 columns). If there are more categories than fit on one page:
  - A subtle right-edge fade/gradient overlay (from transparent to the sheet's background color, ~26px wide) appears over the grid to hint there's more content to the right — only shown when a next page exists.
  - Paging is **swipe/drag-based**, not button-based: a horizontal drag of at least 40px over the grid area moves to the next/previous page (drag left → next page, drag right → previous page). Implement with the platform's native swipe/pan gesture, not just pointerdown/up deltas (the reference used a simple pointer-position delta since it's a desktop-oriented prototype).
  - Page-position indicator: a row of dots below the grid, centered, `gap: 6px`. Each dot is `6px` diameter, `border-radius: 3px` (so it reads as a small circle/pill), muted color; the active page's dot **widens to 18px** instead of changing to a different shape — same "expanding dot" pattern as an iOS page control. Dots are tappable to jump directly to that page. Dots are hidden entirely when there's only one page.
  - **Do not add prev/next chevron/arrow buttons** — the dots + swipe affordance are the only paging UI, deliberately kept minimal.
- Tapping a category tile:
  - If that category has subcategories defined → advance to **Level 2** for that category (see below).
  - If it has no subcategories → select it directly as the final category and close the modal.

### 5. Category Modal — Level 2 (subcategories)
Same sheet/modal shell, contents swap in place (no new modal layer).
- Header row: circular back-chevron button (`32×32px`) on the left → returns to Level 1 (grid + search + page position all preserved), the general category's name as the title (`17px / 800`, truncates), and the same close (X) button on the right.
- Grid: same 3-column layout and tile styling as Level 1, but:
  - No pagination on this level (subcategory lists are short, 3–4 items).
  - **First tile is always the general category itself again** (e.g. "Transporte"), so the user can pick the broad category with no subcategory if that's all they need — styled with the same icon but a slightly softer tint background than the plain subcategory tiles, to visually mark it as "the general one."
  - Remaining tiles are the subcategories (e.g. under Transporte: Gasolina, Taxi, Estacionamiento, Transporte público), each with its own icon but inheriting the parent category's color.
- Tapping any tile here selects that name as the final category and closes the modal.

## Interactions & Behavior summary
- Mode toggle button: flips `catExpMode` between `'tags'` and `'category'`. Purely a display toggle; doesn't touch the selected category value.
- Opening the modal always starts at Level 1, page 0, empty search query.
- Search resets the page to 0 on every keystroke.
- Swipe gesture only active on the Level 1 grid.
- Selecting a final category (from either level, or a no-subcategory Level-1 tile) writes that name into the same `category` state the tags mode uses, and closes the whole modal stack back to the add sheet.
- Backdrop tap or the X button closes the modal at any level without changing the current selection.
- Closing the whole add sheet (e.g. via its own close action) also resets/closes this modal if it was open.

## Design Tokens (as used in the reference; map to the app's own theme)
- Modal backdrop: `rgba(0,0,0,.6)`
- Sheet background: theme "surface" color
- Sheet radius: `30px` top / `44px` bottom
- Grid tile radius: `16px`; icon swatch radius: `12px`
- Icon swatch size: `36×36px`; icon size inside: `16px`
- Tile padding: `11px 6px`; grid gap: `8px`
- Category color tint for swatch backgrounds: **~14% opacity of the category's hex color** — used consistently for both the collapsed field's swatch and every grid tile's swatch. This soft tint (not a solid fill) is the fix requested after the first pass looked too heavy.
- Custom tile: dashed border, transparent fill, muted (tertiary) text/icon color
- Page dot: `6px` inactive / `18px` active, both `6px` tall, `3px` radius, `6px` gap between dots
- Text sizes: section label `11.5px/700` uppercase; modal title `17px/800`; tile label `11px/700`; field label `14px/700`

## Category Data (mock, for the demo — replace with real data source)
General categories (expense): Comida, Transporte, Compras, Ocio, Salud, Hogar, Educación, Mascotas, Suscripciones, Viajes, Seguros, Impuestos.
General categories (income): Salario, Freelance, Regalo, Inversiones, Reembolso, Ventas, Bonos, Alquiler, Otros.
Each maps to an icon + brand color (see `catMeta` in the source file) and most map to 3–4 subcategories (see `catTree` in the source file), e.g.:
- Transporte → Gasolina, Taxi, Estacionamiento, Transporte público
- Compras → Ropa, Regalos, Electrónica, Varios
- Ocio → Cine, Streaming, Hobby, Salidas

These are illustrative mocks the user asked for to make paging/search meaningfully testable — not a final taxonomy.

## Assets
Icons: [Phosphor Icons](https://phosphoricons.com/) (`ph` / `ph-bold` webfont classes in the reference, e.g. `ph ph-car-profile`, `ph ph-gas-pump`, `ph-bold ph-caret-left`). No raster/image assets used.

## Files
- `Moneta.dc.html` — full source. Search for these markers to find the relevant code:
  - Template: comments `<!-- floating: cambiar de exploración -->`, `<!-- exploración: categoría única con selector en 2 niveles -->`, `<!-- exploración: modal grande de categoría en 2 niveles -->`
  - Logic/handlers: `toggleCatExpMode`, `openCatModal`, `closeCatModal`, `selectGeneralCat`, `backToGeneralCats`, `pickCategoryFinal`, `setCatSearchQuery`, `onGenPointerDown` / `onGenPointerUp`
  - Data: `catMeta` (category → icon/color) and `catTree` (category → subcategory list) class fields
  - Computed view-model: search for `catModalGenerals`, `catGenDots`, `catModalSubItems` inside the render method
